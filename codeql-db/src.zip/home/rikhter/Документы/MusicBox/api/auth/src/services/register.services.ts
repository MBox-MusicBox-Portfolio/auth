
export const checkUser=(user:any):boolean=>{
   return user.dataValues.length() > 0;
}

